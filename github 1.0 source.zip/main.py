import pygame as py
import draw_win
import os
import math

# [
# COMPILING:
# Navigate to folder (D:/stupidgametests/obj-oriented-tests/pygame-tests/itemtest/game-files)
# Compile with pyinstaller (pyinstaller main.py --onefile --noconsole)
# Copy Assets folder to dist
# Done!
# ]

WIDTH, HEIGHT = 600, 600
BROWN = (100, 60, 40)
FPS = 120
VEL = 3
CURSOR_SIZE = 28
DEBUG_MODE = True
WIN = py.display.set_mode((WIDTH, HEIGHT))
ver = "1.0"
py.display.set_caption("first item test")
CHAR_HEIGHT, CHAR_WIDTH = 90, 80
GUN_HEIGHT, GUN_WIDTH = 30, 40
SWORD_HEIGHT, SWORD_WIDTH = 60, 50
BULL_HEIGHT, BULL_WIDTH = 7, 15


CHARACTER_IMG = py.image.load(os.path.join("Assets", "Images", "sussy baka.png"))
GUN_IMG = py.image.load(os.path.join("Assets", "Images", "gun lol.png"))
SWORD_IMG = py.image.load(os.path.join("Assets", "Images", "sword lol.png"))
CH_IMG = py.image.load(os.path.join("Assets", "Images", "crosshair.png"))
BULLET_IMG = py.image.load(os.path.join("Assets", "Images", "bullet.png"))


CHARACTER = py.transform.scale(CHARACTER_IMG, (CHAR_WIDTH, CHAR_HEIGHT))
GUN = py.transform.scale(GUN_IMG, (GUN_WIDTH, GUN_HEIGHT))
SWORD = py.transform.scale(SWORD_IMG, (SWORD_WIDTH, SWORD_HEIGHT))
CH = py.transform.scale(CH_IMG, (CURSOR_SIZE, CURSOR_SIZE))
BULLET = py.transform.scale(BULLET_IMG, (BULL_WIDTH, BULL_HEIGHT))


py.display.set_icon(py.transform.scale(SWORD_IMG, (100, 100)))


def handle_movement(keys_pressed, char):
    if keys_pressed[py.K_a] and char.x > VEL:
        char.x -= VEL
    if keys_pressed[py.K_d] and char.x < WIDTH - char.width - VEL:
        char.x += VEL
    if keys_pressed[py.K_w] and char.y > VEL:
        char.y -= VEL
    if keys_pressed[py.K_s] and char.y < HEIGHT - char.height - VEL:
        char.y += VEL


def main():
    char = py.Rect((WIDTH / 2) - (CHAR_WIDTH / 2), (HEIGHT / 2) - (CHAR_HEIGHT / 2), CHAR_WIDTH, CHAR_HEIGHT)
    gun_rect = py.Rect((WIDTH / 2) - (GUN_WIDTH / 2), (HEIGHT / 2) - (GUN_HEIGHT / 2), GUN_WIDTH, GUN_HEIGHT)
    sword_rect = py.Rect((WIDTH / 2) - (GUN_WIDTH / 2), (HEIGHT / 2) - (SWORD_HEIGHT / 2), SWORD_WIDTH, SWORD_HEIGHT)
    bull_rect = py.Rect((WIDTH / 2) - (GUN_WIDTH / 2), (HEIGHT / 2) - (BULL_HEIGHT / 2), BULL_WIDTH, BULL_HEIGHT)
    github = True
    dir_walked = "Right"
    item = 0  # Item0 = sword, Item1 = gun
    mx = py.mouse.get_pos()[0]
    my = py.mouse.get_pos()[1]

    clock = py.time.Clock()
    RUN = True
    SHOOT = True
    BULLET_MOVE = [0, 0]
    while RUN:
        clock.tick(FPS)
        for event in py.event.get():
            if event.type == py.QUIT:
                RUN = False
            elif event.type == py.MOUSEBUTTONDOWN:
                if item == 1:
                    if SHOOT:
                        BULLET_MOVE = py.mouse.get_pos()
                        print(BULLET_MOVE)
            elif event.type == py.KEYDOWN and event.key == py.K_r:
                if item == 0:
                    item = 1
                    print(f"now gun (item value: {item})")
                elif item == 1:
                    item = 0
                    print(f"now sword (item value: {item})")
                pass
            elif event.type == py.KEYDOWN and event.key == py.K_z:
                pass

        keys_pressed = py.key.get_pressed()
        handle_movement(keys_pressed, char)
        if keys_pressed[py.K_d]:
            dir_walked = "Right"
        elif keys_pressed[py.K_a]:
            dir_walked = "Left"

        draw_win.draw_window(WIN, CHARACTER, CH, CURSOR_SIZE, char, gun_rect, bull_rect, sword_rect, BULLET_MOVE, SHOOT, GUN, BULLET, SWORD, item, ver, WIDTH, HEIGHT, dir_walked, github)

    py.quit()


if __name__ == "__main__":  # checks if name of file is main btw
    main()
