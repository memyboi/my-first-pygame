import pygame as py
import os
import math
py.font.init()


def draw_window(WIN, CHARACTER, CH, CURSOR_SIZE, char, gun_rect, bull_rect, sword_rect, BULLET_MOVE, SHOOT, GUN, BULLET, SWORD, ITEM, ver, win_width, win_height, dir_walked, github):
    WIN.fill((100, 60, 40))
    font = py.font.SysFont("calibri", 20)
    if not github:
        text = font.render(f"v{ver}", 1, (255, 255, 255))
    else:
        text = font.render(f"github release {ver}", 1, (255, 255, 255))
    WIN.blit(text, (1, 1))
    mx = py.mouse.get_pos()[0]
    my = py.mouse.get_pos()[1]
    correction_angle = 170
    correction_angles = 180
    gun_pos = (char.x + 40, char.y + 50)
    if dir_walked == "Right":
        rot_sword = py.transform.rotate(SWORD, 35)
        sword_pos = (char.x + 45, char.y + 25)
    elif dir_walked == "Left":
        rot_sword = py.transform.rotate(SWORD, 55)
        sword_pos = (char.x + 10, char.y + 25)
    gun_rect = GUN.get_rect(center=gun_pos)
    sword_rect = SWORD.get_rect(center=sword_pos)
    bull_pos = BULLET_MOVE
    bull_rect = BULLET.get_rect(center=bull_pos)

    staticMouse = (mx, my)

    dx, dy = mx - gun_rect.centerx, my - gun_rect.centery
    angle = math.degrees(math.atan2(-dy, dx)) - correction_angle

    dxs, dys = staticMouse[0] - bull_rect.centerx, staticMouse[1] - bull_rect.centery
    angles = math.degrees(math.atan2(-dxs, dys)) - correction_angles

    rot_gun = py.transform.rotate(GUN, angle)
    rot_bull = py.transform.rotate(BULLET, angles)
    rot_rect_gun = rot_gun.get_rect(center=gun_rect.center)
    rot_rect_bull = rot_bull.get_rect(center=bull_rect.center)

    if ITEM == 1:
        if SHOOT:
            WIN.blit(BULLET, BULLET_MOVE)
    WIN.blit(CHARACTER, (char.x, char.y))
    if ITEM == 0:
        WIN.blit(rot_sword, sword_rect)
        text = font.render("Press R to swap items (Currently sword)", 1, (255, 255, 255))
        WIN.blit(text, WIN.blit(text, (win_width - text.get_width() - 1, 1)))
    elif ITEM == 1:
        WIN.blit(rot_gun, rot_rect_gun)
        text = font.render("Press R to swap items (Currently gun)", 1, (255, 255, 255))
        WIN.blit(text, WIN.blit(text, (win_width - text.get_width() - 1, 1)))
    py.mouse.set_visible(False)
    WIN.blit(CH, ((mx - (CURSOR_SIZE / 2)), (my - (CURSOR_SIZE / 2))))
    py.display.update()
